package com.example.demo.service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class OtpService {

    private static final Logger logger = LoggerFactory.getLogger(OtpService.class);

    private final Map<Long, OtpEntry> pendingOtps = new ConcurrentHashMap<>();
    private final long expirationMs;
    private final EmailService emailService;

    public OtpService(@Value("${otp.expiration-ms}") long expirationMs, EmailService emailService) {
        this.expirationMs = expirationMs;
        this.emailService = emailService;
    }

    public String createOtp(Long transactionId, String recipient) {
        String otp = String.format("%06d", new Random().nextInt(900000) + 100000);
        OtpEntry entry = new OtpEntry(otp, Instant.now().plus(expirationMs, ChronoUnit.MILLIS));
        pendingOtps.put(transactionId, entry);
        
        logger.info("Creating OTP for transaction {} to recipient: {}", transactionId, recipient);
        
        // Send OTP via email
        try {
            emailService.sendOtpEmail(recipient, otp);
            logger.info("✓ [OTP] OTP sent successfully to email: {}", recipient);
        } catch (Exception e) {
            logger.error("✗ [OTP] Failed to send OTP to email: {}", recipient, e);
            // Fall back to console logging if email fails
            System.out.printf("[OTP] Transaction %d -> %s: %s (Email send failed: %s)%n", transactionId, recipient, otp, e.getMessage());
            throw new RuntimeException("Failed to send OTP email", e);
        }
        
        return otp;
    }

    public boolean verifyOtp(Long transactionId, String otp) {
        OtpEntry entry = pendingOtps.get(transactionId);
        if (entry == null || Instant.now().isAfter(entry.expiry)) {
            pendingOtps.remove(transactionId);
            return false;
        }
        boolean valid = entry.value.equals(otp.trim());
        if (valid) {
            pendingOtps.remove(transactionId);
        }
        return valid;
    }

    private static class OtpEntry {
        private final String value;
        private final Instant expiry;

        public OtpEntry(String value, Instant expiry) {
            this.value = value;
            this.expiry = expiry;
        }
    }
}
