package com.example.demo.controller;

import com.example.demo.dto.MessageResponse;
import com.example.demo.dto.OtpVerifyRequest;
import com.example.demo.dto.TransferRequest;
import com.example.demo.service.TransactionService;
import jakarta.validation.Valid;
import java.security.Principal;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping("/initiate")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<MessageResponse> initiateTransfer(Principal principal, @Valid @RequestBody TransferRequest request) {
        return ResponseEntity.ok(transactionService.initiateTransfer(principal.getName(), request));
    }

    @PostMapping("/verify")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<MessageResponse> verifyTransfer(Principal principal, @Valid @RequestBody OtpVerifyRequest request) {
        return ResponseEntity.ok(transactionService.verifyTransfer(principal.getName(), request));
    }
}
