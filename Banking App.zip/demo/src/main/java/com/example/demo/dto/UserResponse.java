package com.example.demo.dto;

public class UserResponse {

    private Long id;
    private String name;
    private String email;
    private String role;
    private boolean accountLocked;
    private int failedAttempts;

    public UserResponse(Long id, String name, String email, String role, boolean accountLocked, int failedAttempts) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.role = role;
        this.accountLocked = accountLocked;
        this.failedAttempts = failedAttempts;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isAccountLocked() {
        return accountLocked;
    }

    public void setAccountLocked(boolean accountLocked) {
        this.accountLocked = accountLocked;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }
}
