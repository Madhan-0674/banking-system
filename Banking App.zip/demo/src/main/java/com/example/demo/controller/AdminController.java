package com.example.demo.controller;

import com.example.demo.dto.MessageResponse;
import com.example.demo.dto.TransactionResponse;
import com.example.demo.dto.UserResponse;
import com.example.demo.entity.AuditLog;
import com.example.demo.service.AdminService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<UserResponse>> listUsers() {
        return ResponseEntity.ok(adminService.listUsers());
    }

    @PostMapping("/users/{id}/block")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> blockUser(@PathVariable("id") Long id) {
        return ResponseEntity.ok(adminService.blockUser(id));
    }

    @PostMapping("/users/{id}/unlock")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> unlockUser(@PathVariable("id") Long id) {
        return ResponseEntity.ok(adminService.unlockUser(id));
    }

    @GetMapping("/transactions")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<TransactionResponse>> listTransactions() {
        return ResponseEntity.ok(adminService.listTransactions());
    }

    @GetMapping("/audits")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<AuditLog>> listAuditLogs() {
        return ResponseEntity.ok(adminService.listAuditLogs());
    }
}
