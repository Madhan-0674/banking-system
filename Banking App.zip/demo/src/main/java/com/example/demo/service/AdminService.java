package com.example.demo.service;

import com.example.demo.dto.TransactionResponse;
import com.example.demo.dto.UserResponse;
import com.example.demo.entity.AuditLog;
import com.example.demo.entity.TransactionRecord;
import com.example.demo.entity.User;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.AuditLogRepository;
import com.example.demo.repository.TransactionRecordRepository;
import com.example.demo.repository.UserRepository;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {

    private final UserRepository userRepository;
    private final TransactionRecordRepository transactionRecordRepository;
    private final AuditLogRepository auditLogRepository;
    private final AuditService auditService;

    public AdminService(UserRepository userRepository,
                        TransactionRecordRepository transactionRecordRepository,
                        AuditLogRepository auditLogRepository,
                        AuditService auditService) {
        this.userRepository = userRepository;
        this.transactionRecordRepository = transactionRecordRepository;
        this.auditLogRepository = auditLogRepository;
        this.auditService = auditService;
    }

    public List<UserResponse> listUsers() {
        return userRepository.findAll().stream()
                .map(user -> new UserResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name(), user.isAccountLocked(), user.getFailedAttempts()))
                .collect(Collectors.toList());
    }

    @Transactional
    public UserResponse blockUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setAccountLocked(true);
        userRepository.save(user);
        auditService.record("ADMIN", "USER_BLOCKED:" + user.getEmail(), "SYSTEM");
        return new UserResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name(), user.isAccountLocked(), user.getFailedAttempts());
    }

    @Transactional
    public UserResponse unlockUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setAccountLocked(false);
        user.setFailedAttempts(0);
        userRepository.save(user);
        auditService.record("ADMIN", "USER_UNLOCKED:" + user.getEmail(), "SYSTEM");
        return new UserResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name(), user.isAccountLocked(), user.getFailedAttempts());
    }

    public List<TransactionResponse> listTransactions() {
        return transactionRecordRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<AuditLog> listAuditLogs() {
        return auditLogRepository.findAll();
    }

    private TransactionResponse mapToResponse(TransactionRecord record) {
        return new TransactionResponse(record.getId(), record.getSenderAccount(), record.getReceiverAccount(), record.getAmount(), record.getTransactionTime(), record.getStatus());
    }
}
