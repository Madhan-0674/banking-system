package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String senderEmail;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    /**
     * Send OTP via email
     */
    public void sendOtpEmail(String recipientEmail, String otp) {
        try {
            logger.info("Starting to send OTP email to: {}", recipientEmail);
            logger.debug("Sender email: {}", senderEmail);
            
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            String subject = "Your OTP - Bank Application";
            String htmlContent = buildOtpEmailTemplate(otp);

            helper.setFrom(senderEmail);
            helper.setTo(recipientEmail);
            helper.setSubject(subject);
            helper.setText(htmlContent, true);

            mailSender.send(message);
            logger.info("✓ OTP email sent successfully to: {}", recipientEmail);
            System.out.println("✓✓✓ OTP SENT TO EMAIL: " + recipientEmail + " ✓✓✓");
        } catch (MessagingException e) {
            logger.error("✗ Failed to send OTP email to: {}", recipientEmail, e);
            logger.error("Error message: {}", e.getMessage());
            System.err.println("✗✗✗ EMAIL SEND FAILED: " + e.getMessage() + " ✗✗✗");
            throw new RuntimeException("Failed to send OTP email: " + e.getMessage(), e);
        } catch (Exception e) {
            logger.error("✗ Unexpected error while sending OTP email to: {}", recipientEmail, e);
            System.err.println("✗✗✗ UNEXPECTED ERROR: " + e.getMessage() + " ✗✗✗");
            throw new RuntimeException("Failed to send OTP email", e);
        }
    }

    /**
     * Send verification email after successful registration
     */
    public void sendRegistrationConfirmation(String recipientEmail, String userName) {
        try {
            logger.info("Sending registration confirmation email to: {}", recipientEmail);
            
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            String subject = "Welcome to Bank Application";
            String htmlContent = buildRegistrationEmailTemplate(userName);

            helper.setFrom(senderEmail);
            helper.setTo(recipientEmail);
            helper.setSubject(subject);
            helper.setText(htmlContent, true);

            mailSender.send(message);
            logger.info("✓ Registration confirmation email sent to: {}", recipientEmail);
        } catch (MessagingException e) {
            logger.error("✗ Failed to send registration confirmation email to: {}", recipientEmail, e);
        } catch (Exception e) {
            logger.error("✗ Unexpected error while sending registration email to: {}", recipientEmail, e);
        }
    }

    /**
     * Build HTML template for OTP email
     */
    private String buildOtpEmailTemplate(String otp) {
        return "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "    <style>" +
                "        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }" +
                "        .container { max-width: 600px; margin: 50px auto; background-color: #ffffff; padding: 40px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }" +
                "        .header { color: #333; text-align: center; margin-bottom: 30px; }" +
                "        .otp-box { background-color: #f0f0f0; padding: 20px; border-radius: 8px; text-align: center; margin: 30px 0; }" +
                "        .otp-code { font-size: 32px; font-weight: bold; color: #007bff; letter-spacing: 5px; }" +
                "        .expiry { color: #666; font-size: 14px; margin-top: 15px; }" +
                "        .warning { color: #d32f2f; font-weight: bold; margin-top: 20px; }" +
                "        .footer { text-align: center; color: #999; font-size: 12px; margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px; }" +
                "    </style>" +
                "</head>" +
                "<body>" +
                "    <div class='container'>" +
                "        <div class='header'>" +
                "            <h2>Your One-Time Password (OTP)</h2>" +
                "        </div>" +
                "        <p>Hello,</p>" +
                "        <p>You have requested a One-Time Password (OTP) for your Bank Application account. Please use the code below to complete your verification.</p>" +
                "        <div class='otp-box'>" +
                "            <div class='otp-code'>" + otp + "</div>" +
                "        </div>" +
                "        <p class='expiry'>This OTP is valid for <strong>5 minutes</strong> only.</p>" +
                "        <p class='warning'>⚠️ Never share this OTP with anyone. Our support team will never ask for your OTP.</p>" +
                "        <p>If you did not request this OTP, please ignore this email or contact our support team.</p>" +
                "        <div class='footer'>" +
                "            <p>&copy; 2026 Bank Application. All rights reserved.</p>" +
                "            <p>This is an automated message, please do not reply to this email.</p>" +
                "        </div>" +
                "    </div>" +
                "</body>" +
                "</html>";
    }

    /**
     * Build HTML template for registration confirmation email
     */
    private String buildRegistrationEmailTemplate(String userName) {
        return "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "    <style>" +
                "        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }" +
                "        .container { max-width: 600px; margin: 50px auto; background-color: #ffffff; padding: 40px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }" +
                "        .header { color: #333; text-align: center; margin-bottom: 30px; }" +
                "        .welcome { background-color: #28a745; color: white; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; font-size: 18px; }" +
                "        .footer { text-align: center; color: #999; font-size: 12px; margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px; }" +
                "    </style>" +
                "</head>" +
                "<body>" +
                "    <div class='container'>" +
                "        <div class='header'>" +
                "            <h2>Welcome to Bank Application!</h2>" +
                "        </div>" +
                "        <p>Hi <strong>" + userName + "</strong>,</p>" +
                "        <p>Thank you for registering with our Bank Application. Your account has been successfully created!</p>" +
                "        <div class='welcome'>" +
                "            Your account is now active and ready to use." +
                "        </div>" +
                "        <p><strong>What's next?</strong></p>" +
                "        <ul>" +
                "            <li>Complete your profile</li>" +
                "            <li>Add beneficiaries</li>" +
                "            <li>Start making transactions</li>" +
                "        </ul>" +
                "        <p>If you have any questions or need assistance, please contact our support team.</p>" +
                "        <div class='footer'>" +
                "            <p>&copy; 2026 Bank Application. All rights reserved.</p>" +
                "            <p>This is an automated message, please do not reply to this email.</p>" +
                "        </div>" +
                "    </div>" +
                "</body>" +
                "</html>";
    }
}
