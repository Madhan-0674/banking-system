package com.example.demo;

import com.example.demo.entity.BankAccount;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.repository.BankAccountRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final BankAccountRepository bankAccountRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           BankAccountRepository bankAccountRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.bankAccountRepository = bankAccountRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (!userRepository.existsByEmail("admin@bank.com")) {
            User admin = new User();
            admin.setName("Admin");
            admin.setEmail("admin@bank.com");
            admin.setPassword(passwordEncoder.encode("Admin@123"));
            admin.setRole(Role.ROLE_ADMIN);
            admin.setFailedAttempts(0);
            admin.setAccountLocked(false);
            BankAccount account = new BankAccount("ADMIN000000", 0.0, admin);
            admin.setBankAccount(account);
            userRepository.save(admin);
            System.out.println("Created default admin user admin@bank.com with password Admin@123");
        }
    }
}
