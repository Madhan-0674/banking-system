package com.example.demo.service;

import com.example.demo.dto.BalanceResponse;
import com.example.demo.dto.TransactionResponse;
import com.example.demo.entity.BankAccount;
import com.example.demo.entity.TransactionRecord;
import com.example.demo.entity.User;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.BankAccountRepository;
import com.example.demo.repository.TransactionRecordRepository;
import com.example.demo.repository.UserRepository;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    private final UserRepository userRepository;
    private final BankAccountRepository bankAccountRepository;
    private final TransactionRecordRepository transactionRecordRepository;

    public AccountService(UserRepository userRepository,
                          BankAccountRepository bankAccountRepository,
                          TransactionRecordRepository transactionRecordRepository) {
        this.userRepository = userRepository;
        this.bankAccountRepository = bankAccountRepository;
        this.transactionRecordRepository = transactionRecordRepository;
    }

    public BalanceResponse getBalance(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        BankAccount account = user.getBankAccount();
        return new BalanceResponse(account.getAccountNumber(), account.getBalance());
    }

    public List<TransactionResponse> getTransactionHistory(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return transactionRecordRepository.findByInitiatedByOrderByTransactionTimeDesc(email).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private TransactionResponse mapToResponse(TransactionRecord record) {
        return new TransactionResponse(record.getId(), record.getSenderAccount(), record.getReceiverAccount(), record.getAmount(), record.getTransactionTime(), record.getStatus());
    }
}
