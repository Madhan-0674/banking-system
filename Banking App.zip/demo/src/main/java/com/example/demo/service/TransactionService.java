package com.example.demo.service;

import com.example.demo.dto.MessageResponse;
import com.example.demo.dto.OtpVerifyRequest;
import com.example.demo.dto.TransferRequest;
import com.example.demo.entity.BankAccount;
import com.example.demo.entity.TransactionRecord;
import com.example.demo.entity.User;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.BankAccountRepository;
import com.example.demo.repository.TransactionRecordRepository;
import com.example.demo.repository.UserRepository;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransactionService {

    private final UserRepository userRepository;
    private final BankAccountRepository bankAccountRepository;
    private final TransactionRecordRepository transactionRecordRepository;
    private final OtpService otpService;
    private final AuditService auditService;

    public TransactionService(UserRepository userRepository,
                              BankAccountRepository bankAccountRepository,
                              TransactionRecordRepository transactionRecordRepository,
                              OtpService otpService,
                              AuditService auditService) {
        this.userRepository = userRepository;
        this.bankAccountRepository = bankAccountRepository;
        this.transactionRecordRepository = transactionRecordRepository;
        this.otpService = otpService;
        this.auditService = auditService;
    }

    @Transactional
    public MessageResponse initiateTransfer(String email, TransferRequest request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        BankAccount sender = bankAccountRepository.findByAccountNumber(request.getSenderAccount())
                .orElseThrow(() -> new ResourceNotFoundException("Sender account not found"));
        if (!sender.getUser().getId().equals(user.getId())) {
            throw new BadRequestException("Sender account does not belong to the authenticated user");
        }

        BankAccount receiver = bankAccountRepository.findByAccountNumber(request.getReceiverAccount())
                .orElseThrow(() -> new ResourceNotFoundException("Receiver account not found"));

        if (sender.getBalance() < request.getAmount()) {
            throw new BadRequestException("Insufficient balance");
        }

        TransactionRecord record = new TransactionRecord(request.getSenderAccount(), request.getReceiverAccount(), request.getAmount(), LocalDateTime.now(), "PENDING", email);
        transactionRecordRepository.save(record);

        String otp = otpService.createOtp(record.getId(), user.getEmail());
        auditService.record(email, "TRANSFER_INITIATED", sender.getAccountNumber());

        return new MessageResponse("OTP sent to registered email. Use transactionId=" + record.getId() + " and OTP " + otp + " to verify the transaction.");
    }

    @Transactional
    public MessageResponse verifyTransfer(String email, OtpVerifyRequest request) {
        TransactionRecord record = transactionRecordRepository.findById(request.getTransactionId())
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found"));

        if (!record.getInitiatedBy().equals(email)) {
            throw new BadRequestException("You are not authorized to verify this transaction");
        }
        if (!"PENDING".equals(record.getStatus())) {
            throw new BadRequestException("Transaction is not pending verification");
        }

        if (!otpService.verifyOtp(record.getId(), request.getOtp())) {
            throw new BadRequestException("Invalid or expired OTP");
        }

        BankAccount sender = bankAccountRepository.findByAccountNumber(record.getSenderAccount())
                .orElseThrow(() -> new ResourceNotFoundException("Sender account not found"));
        BankAccount receiver = bankAccountRepository.findByAccountNumber(record.getReceiverAccount())
                .orElseThrow(() -> new ResourceNotFoundException("Receiver account not found"));

        if (sender.getBalance() < record.getAmount()) {
            record.setStatus("FAILED");
            transactionRecordRepository.save(record);
            throw new BadRequestException("Insufficient balance for transfer");
        }

        sender.setBalance(sender.getBalance() - record.getAmount());
        receiver.setBalance(receiver.getBalance() + record.getAmount());
        bankAccountRepository.save(sender);
        bankAccountRepository.save(receiver);

        record.setStatus("COMPLETED");
        record.setTransactionTime(LocalDateTime.now());
        transactionRecordRepository.save(record);

        auditService.record(email, "TRANSFER_COMPLETED", sender.getAccountNumber());
        return new MessageResponse("Transfer completed successfully.");
    }
}
