package com.example.demo.controller;

import com.example.demo.dto.BalanceResponse;
import com.example.demo.dto.TransactionResponse;
import com.example.demo.service.AccountService;
import java.security.Principal;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping("/balance")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<BalanceResponse> getBalance(Principal principal) {
        return ResponseEntity.ok(accountService.getBalance(principal.getName()));
    }

    @GetMapping("/transactions")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<List<TransactionResponse>> getTransactions(Principal principal) {
        return ResponseEntity.ok(accountService.getTransactionHistory(principal.getName()));
    }
}
