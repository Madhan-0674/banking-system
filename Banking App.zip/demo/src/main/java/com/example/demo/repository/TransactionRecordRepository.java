package com.example.demo.repository;

import com.example.demo.entity.TransactionRecord;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRecordRepository extends JpaRepository<TransactionRecord, Long> {
    List<TransactionRecord> findByInitiatedByOrderByTransactionTimeDesc(String initiatedBy);
}
