# Bank Application - Web Interface Setup

## 🚀 How to Access the Web Interface

### Step 1: Build and Run the Application
```bash
mvn clean install
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

### Step 2: Access the Web Interface
Open your browser and go to:
- **Main Page**: http://localhost:8080/
- **App Page**: http://localhost:8080/app

### Features Available

#### 1. **Authentication**
- **Register**: Create a new account with name, email, and password
- **Login**: Login with your email and password

#### 2. **Dashboard** (After Login)
After successful login, you'll see a dashboard with:

##### Balance Section
- View your current account balance
- View your account number
- Refresh balance anytime

##### Transfer Section
- Initiate a money transfer
- Enter sender account, receiver account, and amount
- System automatically sends OTP to your email
- Verify transfer with OTP (6 digits)

##### Transactions Section
- View all transaction history
- See transaction status (COMPLETED, PENDING, FAILED)
- View transaction details including dates

#### 3. **Admin Features** (If logged in as ADMIN)
Additional tabs become available:

##### Users Management
- View all registered users
- See user details (ID, name, email, role)
- Block/Unlock user accounts

##### All Transactions
- View all transactions in the system
- Monitor all user transactions
- Track transaction status

---

## 📧 Email Configuration

The application sends OTP via email. Make sure email credentials are configured in `application.properties`:

```properties
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=your_email@gmail.com
spring.mail.password=your_app_password
```

### For Gmail Users:
1. Enable 2-Step Verification: https://myaccount.google.com/security
2. Generate App Password: https://myaccount.google.com/apppasswords
3. Use the 16-character app password in `application.properties`

---

## 🔐 Security Features

- JWT Token-based authentication
- Password encryption using BCrypt
- Role-based access control (USER and ADMIN)
- Account locking after 5 failed login attempts
- OTP verification for money transfers
- CORS enabled for frontend communication
- Secure email sending for OTP

---

## 📱 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Account
- `GET /api/accounts/balance` - Get account balance (requires JWT token)
- `GET /api/accounts/transactions` - Get transaction history (requires JWT token)

### Transactions
- `POST /api/transactions/initiate` - Initiate money transfer (requires JWT token)
- `POST /api/transactions/verify` - Verify transfer with OTP (requires JWT token)

### Admin
- `GET /api/admin/users` - List all users (requires ADMIN role)
- `POST /api/admin/users/{id}/block` - Block user (requires ADMIN role)
- `POST /api/admin/users/{id}/unlock` - Unlock user (requires ADMIN role)
- `GET /api/admin/transactions` - List all transactions (requires ADMIN role)

---

## 🧪 Test Scenarios

### Scenario 1: Register and Login
1. Click "Register"
2. Fill in Name, Email, and Password
3. Click "Register" button
4. Wait for success message
5. Click "Login"
6. Enter your email and password
7. Click "Login" button

### Scenario 2: Check Balance
1. Login to dashboard
2. Click "Balance" tab
3. View your account balance and account number

### Scenario 3: Transfer Money
1. Login to dashboard
2. Click "Transfer" tab
3. Enter sender account (auto-filled), receiver account, and amount
4. Click "Send OTP"
5. Check your email for OTP
6. Enter OTP in the form
7. Click "Verify & Complete Transfer"
8. Monitor the transfer in "Transactions" tab

### Scenario 4: Admin Functions
1. Login as admin user
2. Click "Admin" tab
3. View users and transactions
4. Block/Unlock users as needed

---

## 🛠️ Troubleshooting

### Issue: CORS Error
- Make sure CORS is enabled in SecurityConfig
- Check if API is running on http://localhost:8080

### Issue: Email not receiving OTP
- Verify email configuration in `application.properties`
- Check email spam folder
- Ensure app password is correct for Gmail

### Issue: JWT Token Expired
- Token expires after 1 hour (configurable in `application.properties`)
- Login again to get a new token

### Issue: Account Locked
- After 5 failed login attempts, account gets locked
- Admin can unlock the account from Admin panel

---

## 📝 Notes

- All passwords are encrypted using BCrypt
- Tokens are stored in browser's localStorage
- OTP is valid for 5 minutes
- Initial account balance is $1000 for new users
- Email credentials in properties file are for demonstration - replace with your own

---

## 🎨 UI/UX Features

- Responsive design (works on desktop and mobile)
- Real-time validation
- Loading spinners for async operations
- Success/Error messages
- Professional styling with purple gradient theme
- Easy navigation between sections
- Logout button on dashboard

---

**Happy Banking! 🏦**
