package com.example.demo.service;

import com.example.demo.dto.JwtResponse;
import com.example.demo.dto.LoginRequest;
import com.example.demo.dto.MessageResponse;
import com.example.demo.dto.SignupRequest;
import com.example.demo.entity.BankAccount;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.exception.BadRequestException;
import com.example.demo.repository.BankAccountRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtProvider;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Locale;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private static final int MAX_FAILED_ATTEMPTS = 5;

    private final UserRepository userRepository;
    private final BankAccountRepository bankAccountRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtProvider jwtProvider;
    private final AuditService auditService;

    public AuthService(UserRepository userRepository,
                       BankAccountRepository bankAccountRepository,
                       PasswordEncoder passwordEncoder,
                       AuthenticationManager authenticationManager,
                       JwtProvider jwtProvider,
                       AuditService auditService) {
        this.userRepository = userRepository;
        this.bankAccountRepository = bankAccountRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtProvider = jwtProvider;
        this.auditService = auditService;
    }

    @Transactional
    public MessageResponse register(SignupRequest request) {
        if (userRepository.existsByEmail(request.getEmail().toLowerCase(Locale.ROOT))) {
            throw new BadRequestException("Email already registered");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail().toLowerCase(Locale.ROOT));
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(Role.ROLE_USER);
        user.setFailedAttempts(0);
        user.setAccountLocked(false);

        BankAccount bankAccount = new BankAccount(generateAccountNumber(), 1000.00, user);
        user.setBankAccount(bankAccount);
        bankAccount.setUser(user);

        userRepository.save(user);
        bankAccountRepository.save(bankAccount);

        auditService.record(user.getEmail(), "USER_REGISTERED", "SYSTEM");
        return new MessageResponse("Registration successful. Your account has been created.");
    }

    public JwtResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail().toLowerCase(Locale.ROOT))
                .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));

        if (user.isAccountLocked()) {
            throw new BadRequestException("Your account is locked. Contact admin.");
        }

        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
            user.setFailedAttempts(0);
            userRepository.save(user);
            String token = jwtProvider.generateToken(user.getEmail());
            auditService.record(user.getEmail(), "LOGIN_SUCCESS", "SYSTEM");
            return new JwtResponse(token, user.getId(), user.getName(), user.getEmail(), user.getRole().name());
        } catch (BadCredentialsException ex) {
            incrementFailedAttempts(user);
            throw new BadCredentialsException("Invalid credentials");
        }
    }

    private void incrementFailedAttempts(User user) {
        user.setFailedAttempts(user.getFailedAttempts() + 1);
        if (user.getFailedAttempts() >= MAX_FAILED_ATTEMPTS) {
            user.setAccountLocked(true);
            auditService.record(user.getEmail(), "ACCOUNT_LOCKED", "SYSTEM");
        }
        userRepository.save(user);
    }

    private String generateAccountNumber() {
        SecureRandom random = new SecureRandom();
        String number = new BigInteger(50, random).toString(10);
        return "BA" + String.format("%010d", Long.parseLong(number.substring(Math.max(0, number.length() - 10))));
    }
}
