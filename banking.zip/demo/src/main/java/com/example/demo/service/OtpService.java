package com.example.demo.service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class OtpService {

    private final Map<Long, OtpEntry> pendingOtps = new ConcurrentHashMap<>();
    private final long expirationMs;

    public OtpService(@Value("${otp.expiration-ms}") long expirationMs) {
        this.expirationMs = expirationMs;
    }

    public String createOtp(Long transactionId, String recipient) {
        String otp = String.format("%06d", new Random().nextInt(900000) + 100000);
        OtpEntry entry = new OtpEntry(otp, Instant.now().plus(expirationMs, ChronoUnit.MILLIS));
        pendingOtps.put(transactionId, entry);
        // For demo and audit, log OTP instead of requiring third-party email/SMS
        System.out.printf("[OTP] Transaction %d -> %s: %s%n", transactionId, recipient, otp);
        return otp;
    }

    public boolean verifyOtp(Long transactionId, String otp) {
        OtpEntry entry = pendingOtps.get(transactionId);
        if (entry == null || Instant.now().isAfter(entry.expiry)) {
            pendingOtps.remove(transactionId);
            return false;
        }
        boolean valid = entry.value.equals(otp.trim());
        if (valid) {
            pendingOtps.remove(transactionId);
        }
        return valid;
    }

    private static class OtpEntry {
        private final String value;
        private final Instant expiry;

        public OtpEntry(String value, Instant expiry) {
            this.value = value;
            this.expiry = expiry;
        }
    }
}
